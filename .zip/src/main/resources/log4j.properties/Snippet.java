package snippet;

public class Snippet {
	log4j.rootLogger=TRACE, Appender1, Appender2
	 
	log4j.appender.Appender1=org.apache.log4j.ConsoleAppender
	log4j.appender.Appender1.layout=org.apache.log4j.PatternLayout
	log4j.appender.Appender1.layout.ConversionPattern=%-7p %d [%t] %c %x - %m%n
	 
	
}



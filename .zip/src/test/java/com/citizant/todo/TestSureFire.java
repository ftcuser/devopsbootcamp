package com.citizant.todo;

import org.junit.Test;

public class TestSureFire {
	
@Test
public void testcaseFirst()
	{
 System.out.println("First Test case executed");
  }

@Test
public void testcaseSecond()
{
System.out.println("Second Test case executed");
}
	
@Test
public void testcaseThird()
{
System.out.println("Third Test case executed");
}
@Test
public void testcaseFourth()
{
System.out.println("Fourth Test case executed");
}

}